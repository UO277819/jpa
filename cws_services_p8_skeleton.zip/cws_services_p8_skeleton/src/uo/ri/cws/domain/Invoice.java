package uo.ri.cws.domain;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.StateChecks;

@Entity
@Table(name = "tinvoices")
public class Invoice extends BaseEntity {
    public enum InvoiceState {
	NOT_YET_PAID, PAID
    }

    // natural attributes
    @Column(unique = true)
    @Basic(optional = false)
    private Long number;
    private LocalDate date;
    private double amount;
    private double vat;
    private InvoiceState state = InvoiceState.NOT_YET_PAID;

    // accidental attributes
    @OneToMany(mappedBy = "invoice")
    private Set<WorkOrder> workOrders = new HashSet<>();
    @OneToMany(mappedBy = "invoice")
    private Set<Charge> charges = new HashSet<>();

    public Invoice(Long number) {
	// call full constructor with sensible defaults
	this(number, LocalDate.now());
    }

    public Invoice(Long number, LocalDate date) {
	// call full constructor with sensible defaults
	this(number, date, List.of());
    }

    public Invoice(Long number, List<WorkOrder> workOrders) {
	this(number, LocalDate.now(), workOrders);
    }

    // full constructor
    public Invoice(Long number, LocalDate date, List<WorkOrder> workOrders) {
	// check arguments (always), through IllegalArgumentException
	// store the number
	// store a copy of the date
	// add every work order calling addWorkOrder( w )
	this.number = number;
	this.date = date;
	for (WorkOrder work : workOrders) {
	    addWorkOrder(work);
	}
    }

    /**
     * Computes amount and vat (vat depends on the date)
     */
    private void computeAmount() {
    	double amount = 0;
		for (WorkOrder wo : workOrders) {
			amount+=wo.getAmount();
		}
		
		vat = getDate().isBefore(LocalDate.parse("2021-07-01")) ? 0.18 * amount : 0.21 * amount;
		
		this.amount = Round.twoCents(amount+vat);
    }

    /**
     * Adds (double links) the workOrder to the invoice and updates the amount
     * and vat
     * 
     * @param workOrder
     * @see UML_State diagrams on the problem statement document
     * @throws IllegalStateException if the invoice status is not NOT_YET_PAID
     */
    public void addWorkOrder(WorkOrder workOrder) {
    	if(!state.equals(InvoiceState.NOT_YET_PAID))
			throw new IllegalStateException("Factura sin pagar");
		Associations.ToInvoice.link(this, workOrder);
		
		workOrder.markAsInvoiced();
		computeAmount();
    }

    /**
     * Removes a work order from the invoice and recomputes amount and vat
     * 
     * @param workOrder
     * @see UML_State diagrams on the problem statement document
     * @throws IllegalStateException if the invoice status is not NOT_YET_PAID
     */
    public void removeWorkOrder(WorkOrder workOrder) {
    	if(!state.equals(InvoiceState.NOT_YET_PAID))
			throw new IllegalStateException("Factura sin pagar no");
		Associations.ToInvoice.unlink(this, workOrder);
		workOrders.remove(workOrder);
		computeAmount();
    }

    /**
     * Marks the invoice as PAID, but
     * 
     * @throws IllegalStateException if - Is already settled - Or the amounts
     *                               paid with charges to payment means do not
     *                               cover the total of the invoice
     */
    public void settle() {
    	if(state == InvoiceState.PAID)
			throw new IllegalStateException("ah");
		
		double aPagar = 0.0;
		
		for(Charge ch:charges) {
			aPagar += ch.getAmount();
		}
		
		if(Math.abs(aPagar-amount)<=0.01)
			this.state = InvoiceState.PAID;
		else
			throw new IllegalStateException("ah");
		
		for (WorkOrder w : workOrders) {
			w.readyToUsedForVoucher();
		}
    }

    public Set<WorkOrder> getWorkOrders() {
	return new HashSet<>(workOrders);
    }

    Set<WorkOrder> _getWorkOrders() {
	return workOrders;
    }

    public Set<Charge> getCharges() {
	return new HashSet<>(charges);
    }

    Set<Charge> _getCharges() {
	return charges;
    }

    public Long getNumber() {
	return number;
    }

    public LocalDate getDate() {
	return date;
    }

    public double getAmount() {
	return amount;
    }

    public double getVat() {
	return vat;
    }

    public InvoiceState getState() {
	return state;
    }

    @Override
    public int hashCode() {
	return Objects.hash(number);
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Invoice other = (Invoice) obj;
	return Objects.equals(number, other.number);
    }

    @Override
    public String toString() {
	return "Invoice [number=" + number + ", date=" + date + ", amount="
		+ amount + ", vat=" + vat + ", state=" + state + "]";
    }

}
