package uo.ri.cws.domain;

import java.util.Objects;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tvouchers")
public class Voucher extends PaymentMean {
    @Column(unique = true)
    @Basic(optional = false)
    private String code;

    private double available = 0.0;
    private String description;

    public Voucher(String code, double ammount) {
    	ArgumentChecks.isNotEmpty(code);
		ArgumentChecks.isNotEmpty(available);
		ArgumentChecks.isTrue(ammount>0);
		
		this.code = code;
		this.description = "no descripcion";
		this.available = ammount;
    }

    /**
     * 
     * Augments the accumulated (super.pay(amount) ) and decrements the
     * available
     * 
     * @throws IllegalStateException if not enough available to pay
     */
    @Override
    public void pay(double amount) {
    	if(available - amount<0)
			throw new IllegalStateException();
		super.pay(amount);
		available -= getAccumulated();
    }

    public String getCode() {
	return code;
    }

    public double getAvailable() {
	return available;
    }

    public String getDescription() {
	return description;
    }

    @Override
    public int hashCode() {
	return Objects.hash(code);
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Voucher other = (Voucher) obj;
	return Objects.equals(code, other.code);
    }

    @Override
    public String toString() {
	return "Voucher [code=" + code + ", available=" + available
		+ ", description=" + description + "]";
    }

}
