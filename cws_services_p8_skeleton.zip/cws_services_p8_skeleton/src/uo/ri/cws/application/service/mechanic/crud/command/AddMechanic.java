package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NamedQuery;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;
import uo.ri.util.assertion.ArgumentChecks;

public class AddMechanic implements Command<MechanicDto>{

	private MechanicDto dto;

	public AddMechanic(MechanicDto dto) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotEmpty(dto.dni);
		ArgumentChecks.isNotEmpty(dto.name);
		ArgumentChecks.isNotEmpty(dto.surname);
		ArgumentChecks.isNotBlank(dto.dni);
		ArgumentChecks.isNotBlank(dto.name);
		ArgumentChecks.isNotBlank(dto.surname);
		this.dto = dto;
	}

	public MechanicDto execute() throws BusinessException {
		/*EntityManagerFactory emf=Persistence.createEntityManagerFactory("carWorkshop");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tx=em.getTransaction();
		tx.begin();*/
		//try {
			TypedQuery q=Jpa.getManager().createNamedQuery("Mechanic.findByDni",Mechanic.class).setParameter(1, dto.dni);
			List<Mechanic> l=q.getResultList();
			BusinessChecks.isTrue(l.isEmpty(),"repeated mechanic");
			Mechanic m=new Mechanic(dto.dni,dto.name,dto.surname);
			em.persist(m);
			dto.id=m.getId();
		/*}catch(Exception e) {
			
			if(tx.isActive())
				tx.rollback();
			throw e;
		}finally {
			em.close();
			emf.close();
		}
		tx.commit();*/
		return dto;
	}

}
