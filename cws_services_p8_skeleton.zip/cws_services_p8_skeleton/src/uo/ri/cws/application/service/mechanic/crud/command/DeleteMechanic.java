package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteMechanic implements Command<Void>{

	private String mechanicId;

	public DeleteMechanic(String mechanicId) {
		ArgumentChecks.isNotEmpty(mechanicId);
		ArgumentChecks.isNotBlank(mechanicId);
		this.mechanicId = mechanicId;
	}

	public Void execute() throws BusinessException {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("carWorkshop");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		//TypedQuery q=em.createNamedQuery("Mechanic.delete",Mechanic.class).setParameter(1, mechanicId);
		//List<Mechanic> l=q.getResultList();
		//BusinessChecks.isFalse(l.isEmpty(),"no delete");
		Mechanic m=em.find(Mechanic.class, mechanicId);
		BusinessChecks.isNotNull(m,"Mechanic not exist");
		em.remove(m);
		tx.commit();
		return null;
	}

}
