package uo.ri.cws.application.service.client.crud.command;

import java.util.ArrayList;
import java.util.List;

import alb.util.assertion.ArgumentChecks;
import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;

public class FindClientsRecommendedBy implements Command<List<ClientDto>>{

	private String id;
	private ClientRepository cRepo = Factory.repository.forClient();
	
	public FindClientsRecommendedBy(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id = id;
	}
	
	@Override
	public List<ClientDto> execute() throws BusinessException {
		List<Client> clientes = cRepo.findRecomendedBy(id);
		List<ClientDto> result = new ArrayList<>();
		if(clientes==null)
			return new ArrayList<ClientDto>();	
		for (Client client : clientes) {
			result.add(DtoAssembler.toDto(client));
		}
		return result;
	}
}
