package uo.ri.cws.application.service.client.crud.command;

import java.util.Optional;

import alb.util.assertion.ArgumentChecks;
import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.CashRepository;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.repository.RecommendationRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Address;
import uo.ri.cws.domain.Cash;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.Recommendation;

public class AddClient implements Command<ClientDto> {
	
	private ClientDto dto;
	private String recommenderId;
	private ClientRepository cRepo = Factory.repository.forClient();
	private PaymentMeanRepository pRepo = Factory.repository.forPaymentMean();
	private CashRepository cashr = Factory.repository.forCash();
	private RecommendationRepository rRepo = Factory.repository.forRecomendacion();
	
	public AddClient(ClientDto dto, String recommenderId) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotNull(dto.dni);
		ArgumentChecks.isNotEmpty(dto.dni);
		this.dto = dto;
		this.recommenderId = recommenderId;
	}
	
	@Override
	public ClientDto execute() throws BusinessException {
		Client client=new Client(dto.dni,dto.name,dto.surname,dto.email,dto.phone
				,new Address(dto.addressStreet, dto.addressCity, dto.addressZipcode));
		Cash cash=new Cash(client);
		dto.id=client.getId();
		cRepo.add(client);
		pRepo.add(cash);
		cashr.add(cash);
		if(recommenderId!=null) {
			Optional<Client> clientOp=cRepo.findById(recommenderId);
			BusinessChecks.isTrue(clientOp.isPresent(),"No existe este cliente");
			rRepo.add(new Recommendation(clientOp.get(), client));
		}
		return dto;
	}

}
