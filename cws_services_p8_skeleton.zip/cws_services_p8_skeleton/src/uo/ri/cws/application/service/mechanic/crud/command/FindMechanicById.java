package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.service.mechanic.assembler.MechanicAssembler;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.util.assertion.ArgumentChecks;

public class FindMechanicById implements Command<Optional<MechanicDto>>{

	private String id;

	public FindMechanicById(String id) {
		ArgumentChecks.isNotEmpty(id);
		ArgumentChecks.isNotBlank(id);
		this.id = id;
	}

	public Optional<MechanicDto> execute() throws BusinessException {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("carWorkshop");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		//TypedQuery q=em.createNamedQuery("Mechanic.delete",Mechanic.class).setParameter(1, mechanicId);
		//List<Mechanic> l=q.getResultList();
		//BusinessChecks.isFalse(l.isEmpty(),"no delete");
		Mechanic m=em.find(Mechanic.class, id);
		BusinessChecks.isNotNull(m,"Mechanic not exist");
		Optional<MechanicDto> dto=MechanicAssembler.toOptionalDto(m);
		tx.commit();
		return Optional.empty();
	}

}
