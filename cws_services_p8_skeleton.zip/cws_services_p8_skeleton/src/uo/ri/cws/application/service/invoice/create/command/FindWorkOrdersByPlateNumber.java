package uo.ri.cws.application.service.invoice.create.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import alb.util.assertion.ArgumentChecks;
import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoicingWorkOrderDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Vehicle;
import uo.ri.cws.domain.WorkOrder;

public class FindWorkOrdersByPlateNumber implements Command<List<InvoicingWorkOrderDto>> {

	private String plate;
	private VehicleRepository vehr=Factory.repository.forVehicle();

	public FindWorkOrdersByPlateNumber(String plate) {
		ArgumentChecks.isNotNull(plate);
		ArgumentChecks.isNotEmpty(plate);
		this.plate=plate;
	}

	@Override
	public List<InvoicingWorkOrderDto> execute() throws BusinessException {
		Optional<Vehicle> veh=vehr.findByPlate(plate);
		BusinessChecks.isTrue(veh.isPresent(),"No existe ese coche");
		List<InvoicingWorkOrderDto> result=new ArrayList<>();
		for(WorkOrder work:veh.get().getWorkOrders()) {
			result.add(DtoAssembler.toWorkOrderDtoForWorkRecord(work));
		}
		return result;
	}

}
