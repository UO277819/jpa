package uo.ri.cws.application.service.client.crud.command;

import java.util.Optional;

import alb.util.assertion.ArgumentChecks;
import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;

public class FindClientById implements Command<Optional<ClientDto>>{

	private String id;
	private ClientRepository cRepo = Factory.repository.forClient();
	
	public FindClientById(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id = id;
	}
	
	@Override
	public Optional<ClientDto> execute() throws BusinessException {
		Optional<Client> client=null;
		client=cRepo.findById(id);
		if(client.isEmpty())
			return Optional.empty();
		Client c =client.get();
		return Optional.ofNullable(DtoAssembler.toDto(c));
	}

}
