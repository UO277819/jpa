package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.domain.Mechanic;

public class MechanicJpaRepository
		// extends BaseJpaRepository<Mechanic>
		implements MechanicRepository {

	@Override
	public void add(Mechanic t) {
		// TODO Auto-generated method stub
	}

	@Override
	public void remove(Mechanic t) {
		// TODO Auto-generated method stub
	}

	@Override
	public Optional<Mechanic> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Mechanic> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Mechanic> findByDni(String dni) {
		// TODO Auto-generated method stub
		return null;
	}

}
