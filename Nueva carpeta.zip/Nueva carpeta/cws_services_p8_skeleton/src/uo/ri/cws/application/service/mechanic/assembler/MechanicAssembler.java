package uo.ri.cws.application.service.mechanic.assembler;

import java.util.Optional;

import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.domain.Mechanic;

public class MechanicAssembler {

	public static Optional<MechanicDto> toOptionalDto(Mechanic m) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public static Optional<MechanicDto> toListDto(Optional<MechanicDto> dto) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
