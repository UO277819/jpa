package uo.ri.cws.domain;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tsubstitutions", uniqueConstraints = @UniqueConstraint(columnNames = {
	"intervention_id", "sparePart_id" }))
public class Substitution extends BaseEntity {
    // natural attributes
    private int quantity;

    // accidental attributes
    @ManyToOne(optional = false)
    private SparePart sparePart;
    @ManyToOne(optional = false)
    private Intervention intervention;

    public Substitution(SparePart sp, Intervention intervention2,
	    int cantidad) {
	// TODO Auto-generated constructor stub
	ArgumentChecks.isNotNull(sp);
	ArgumentChecks.isNotNull(intervention2);
	ArgumentChecks.isTrue(cantidad >= 0);
	Associations.Substitute.link(sp, this, intervention2);

    }

    void _setSparePart(SparePart sparePart) {
	this.sparePart = sparePart;
    }

    void _setIntervention(Intervention intervention) {
	this.intervention = intervention;
    }

    public int getQuantity() {
	return quantity;
    }

    public SparePart getSparePart() {
	return sparePart;
    }

    public Intervention getIntervention() {
	return intervention;
    }

}
