package uo.ri.cws.application.service.contracttype.impl.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.ContractType;
import uo.ri.util.assertion.ArgumentChecks;

public class AddContractType 
implements Command<ContractTypeDto> {

	private ContractTypeDto dto;
	ContractTypeRepository ctr=Factory
		.repository.forContractType();

	public AddContractType(ContractTypeDto dto) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotNull(dto.name);
		ArgumentChecks.isNotEmpty(dto.name);
		ArgumentChecks.isTrue(dto.compensationDays>=0);
		this.dto=dto;
	}

	@Override
	public ContractTypeDto execute() 
		throws BusinessException {
		Optional<ContractType> exist=ctr.findByName(dto.name);
		BusinessChecks.isTrue(exist.isEmpty());
		ContractType ct=new ContractType(dto.name,dto.compensationDays);
		this.dto.id=ct.getId();
		ctr.add(ct);
		return dto;
	}

}
