package uo.ri.cws.application.service.contracttype.impl.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.ContractType;
import uo.ri.util.assertion.ArgumentChecks;

public class FindByName
implements Command<Optional<ContractTypeDto>> {

	private String name;
	ContractTypeRepository ctr=Factory
		.repository.forContractType();
	
	public FindByName(String name) {
		ArgumentChecks.isNotNull(name);
		ArgumentChecks.isNotEmpty(name);
		ArgumentChecks.isNotBlank(name);
		this.name=name;
	}

	@Override
	public Optional<ContractTypeDto> execute()
		throws BusinessException {
		Optional<ContractType> exist=ctr.findByName(name);
		if(exist.isEmpty())
			return Optional.ofNullable(null);
		ContractTypeDto dto=DtoAssembler.toDto(exist.get());
		return Optional.ofNullable(dto);
	}

}
