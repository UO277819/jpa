package uo.ri.cws.application.service.contracttype.impl;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contracttype.ContractTypeService;
import uo.ri.cws.application.service.contracttype.impl.commands.AddContractType;
import uo.ri.cws.application.service.contracttype.impl.commands.DeleteContractType;
import uo.ri.cws.application.service.contracttype.impl.commands.FindAllContractTypes;
import uo.ri.cws.application.service.contracttype.impl.commands.FindByName;
import uo.ri.cws.application.service.contracttype.impl.commands.UpdateContractType;
import uo.ri.cws.application.util.command.CommandExecutor;

public class ContractTypeServiceImpl implements ContractTypeService{

	private CommandExecutor executor = Factory
		.executor.forExecutor();
	
	@Override
	public ContractTypeDto addContractType(ContractTypeDto dto)
		throws BusinessException {
		return executor.execute(new AddContractType(dto));
	}

	@Override
	public void deleteContractType(String name) 
		throws BusinessException {
		 executor.execute(new DeleteContractType(name));
	}

	@Override
	public void updateContractType(ContractTypeDto dto)
		throws BusinessException {
		executor.execute(new UpdateContractType(dto));
	}

	@Override
	public Optional<ContractTypeDto> findContractTypeByName(String name) 
		throws BusinessException {
		return executor.execute(new FindByName(name));
	}

	@Override
	public List<ContractTypeDto> findAllContractTypes() 
		throws BusinessException {
		return executor.execute(new FindAllContractTypes());
	}

}
