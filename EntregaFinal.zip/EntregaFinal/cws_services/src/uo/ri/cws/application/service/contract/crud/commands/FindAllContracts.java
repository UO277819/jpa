package uo.ri.cws.application.service.contract.crud.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractSummaryDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;

public class FindAllContracts 
implements Command<List<ContractSummaryDto>> {
	
	ContractRepository cr=Factory
		.repository
		.forContract();
	
	@Override
	public List<ContractSummaryDto> execute() 
		throws BusinessException {
		List<Contract> lista=cr.findAll();
		List<ContractSummaryDto> result=new ArrayList<>();
		for(Contract cont:lista) {
			result.add(DtoAssembler
				.toSummaryDto(cont));
		}
		return result;
	}

}
