package uo.ri.cws.application.repository;

import java.util.Optional;

import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.PaymentMean;

public interface CreditCardRepository
	extends Repository<CreditCard>{

	Optional<PaymentMean> findByCardNumber(String cardNumber);
	
}
