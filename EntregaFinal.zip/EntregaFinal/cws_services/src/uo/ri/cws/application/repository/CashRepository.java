package uo.ri.cws.application.repository;

import uo.ri.cws.domain.Cash;

public interface CashRepository
extends Repository<Cash> {

}
