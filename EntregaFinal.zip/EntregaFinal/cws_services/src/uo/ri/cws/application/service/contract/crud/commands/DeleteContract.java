package uo.ri.cws.application.service.contract.crud.commands;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Contract.ContractState;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteContract implements Command<Void> {

	private String id;
	ContractRepository cr=Factory
		.repository
		.forContract();
	WorkOrderRepository wr=Factory
		.repository
		.forWorkOrder();

	public DeleteContract(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id=id;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Contract> existc=cr.findById(id);
		BusinessChecks.isTrue(existc.isPresent());
		Contract cont=existc.get();
		if(cont.getState()==ContractState.IN_FORCE) {
			List<WorkOrder> lista=wr
				.findByMechanicId(cont
					.getMechanic()
					.get().getId());
			BusinessChecks.isTrue(cont
				.getPayrolls()
				.isEmpty());
			for(WorkOrder work:lista) {
				BusinessChecks
				.isFalse(cont.getStartDate()
					.isBefore(work.getDate().toLocalDate())
					&& cont.getEndDate().get()
					.isAfter(work.getDate().toLocalDate()));
			}
		}
		cr.remove(cont);
		return null;
	}

}
