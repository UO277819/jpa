package uo.ri.cws.application.service.contract.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Contract.ContractState;
import uo.ri.util.assertion.ArgumentChecks;

public class UpdateContract implements Command<Void> {

	private ContractDto dto;
	ContractRepository cr=Factory
		.repository
		.forContract();
	
	public UpdateContract(ContractDto dto) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotNull(dto.id);
		ArgumentChecks.isNotEmpty(dto.id);
		ArgumentChecks.isNotBlank(dto.id);
		ArgumentChecks.isTrue(dto.annualBaseWage>0);
		this.dto=dto;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Contract> exist=cr.findById(dto.id);
		BusinessChecks.isTrue(exist.isPresent());
		Contract cont=exist.get();
		BusinessChecks.isTrue(cont.getState()
			==ContractState.IN_FORCE);
		if(dto.endDate!=null) {
			BusinessChecks.isTrue(dto.startDate
					.isBefore(dto.endDate));
		}
		cont.setWage(dto.annualBaseWage);
		cont.setEndDate(dto.endDate);
		return null;
	}

}
