package uo.ri.cws.application.service.paymentmean.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService;
import uo.ri.cws.application.service.paymentmean.crud.commands.AddCard;
import uo.ri.cws.application.service.paymentmean.crud.commands.AddVoucher;
import uo.ri.cws.application.service.paymentmean.crud.commands.DeletePaymentMean;
import uo.ri.cws.application.service.paymentmean.crud.commands.FindPaymenMeanByClientId;
import uo.ri.cws.application.service.paymentmean.crud.commands.FindPaymenMeanById;
import uo.ri.cws.application.util.command.CommandExecutor;

public class PaymentmeanCrudServiceImpl
implements PaymentMeanCrudService{

	private CommandExecutor executor = Factory
		.executor.forExecutor();
	
	@Override
	public CardDto addCard(CardDto card) 
		throws BusinessException {
		return executor.execute(new AddCard(card));
	}

	@Override
	public VoucherDto addVoucher(VoucherDto voucher) 
		throws BusinessException {
		return executor.execute(new AddVoucher(voucher));
	}

	@Override
	public void deletePaymentMean(String id) 
		throws BusinessException {
		executor.execute(new DeletePaymentMean(id));
	}

	@Override
	public Optional<PaymentMeanDto> findById(String id)
		throws BusinessException {
		return executor.execute(new FindPaymenMeanById(id));
	}

	@Override
	public List<PaymentMeanDto> findPaymentMeansByClientId(String id) 
		throws BusinessException {
		return executor.execute(new FindPaymenMeanByClientId(id));
	}

}
