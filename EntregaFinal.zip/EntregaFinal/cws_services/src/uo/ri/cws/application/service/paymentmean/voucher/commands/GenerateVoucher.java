package uo.ri.cws.application.service.paymentmean.voucher.commands;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;

public class GenerateVoucher implements Command<Integer> {

	@Override
	public Integer execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}
