package uo.ri.cws.application.service.contracttype.impl.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.repository.CreditCardRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.ContractType;

public class FindAllContractTypes 
implements Command<List<ContractTypeDto>> {

	ContractTypeRepository ctr=Factory
		.repository.forContractType();
	CreditCardRepository ccr=Factory
		.repository.forCreditCard();
	
	@Override
	public List<ContractTypeDto> execute() 
		throws BusinessException {
		List<ContractType> lista=ctr.findAll();
		List<ContractTypeDto> result=new ArrayList<>();
		for(ContractType ct:lista) {
			result.add(DtoAssembler.toDto(ct));
		}
		return result;
	}

}
