package uo.ri.cws.application.repository;

public interface RepositoryFactory {

	MechanicRepository forMechanic();
	WorkOrderRepository forWorkOrder();
	PaymentMeanRepository forPaymentMean();
	InvoiceRepository forInvoice();
	ClientRepository forClient();
	SparePartRepository forSparePart();
	InterventionRepository forIntervention();
	VehicleRepository forVehicle();
	VehicleTypeRepository forVehicleType();
	ChargeRepository forCharge();
	CashRepository forCash();
	CreditCardRepository forCreditCard();
	VoucherRepository forVoucher();
	ContractRepository forContract();
	ContractTypeRepository forContractType();
	PayrollRepository forPayrrol();
	ProfessionalGroupRepository forProfessionalGroup();

}
