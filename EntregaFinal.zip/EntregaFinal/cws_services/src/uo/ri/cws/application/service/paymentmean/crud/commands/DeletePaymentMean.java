package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.CashRepository;
import uo.ri.cws.application.repository.CreditCardRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.repository.VoucherRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.cws.domain.Voucher;
import uo.ri.util.assertion.ArgumentChecks;

public class DeletePaymentMean implements Command<Void> {

	VoucherRepository voucher=Factory
			.repository.forVoucher();
	PaymentMeanRepository pay=Factory
			.repository.forPaymentMean();
	CreditCardRepository credit=Factory
			.repository.forCreditCard();
	CashRepository cash=Factory
			.repository.forCash();
	String id;
	
	public DeletePaymentMean(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id=id;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<PaymentMean> exist=pay.findById(id);
		BusinessChecks.isFalse(exist.isEmpty());
		PaymentMean p=exist.get();
		BusinessChecks.isTrue(p.getCharges().isEmpty());
		BusinessChecks.isTrue(cash.findById(id).isEmpty());
		if(voucher.findById(id).isPresent())
			voucher.remove((Voucher)p);
		else
			credit.remove((CreditCard) p);
		pay.remove(p);
		return null;
	}

}
