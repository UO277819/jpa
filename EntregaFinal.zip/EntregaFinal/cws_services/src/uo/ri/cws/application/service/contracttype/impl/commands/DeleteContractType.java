package uo.ri.cws.application.service.contracttype.impl.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.ContractType;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteContractType implements Command<Void> {
	
	ContractTypeRepository ctr=Factory
		.repository.forContractType();
	
	private String name;

	public DeleteContractType(String name) {
		ArgumentChecks.isNotNull(name);
		ArgumentChecks.isNotEmpty(name);
		ArgumentChecks.isNotBlank(name);
		this.name=name;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<ContractType> exist=ctr.findByName(name);
		BusinessChecks.isTrue(exist.isPresent());
		ContractType ct=exist.get();
		BusinessChecks.isTrue(ct.getContracts().isEmpty());
		ctr.remove(ct);
		return null;
	}

}
