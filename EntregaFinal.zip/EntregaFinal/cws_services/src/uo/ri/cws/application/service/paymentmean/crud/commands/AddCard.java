package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.time.LocalDate;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.CreditCardRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.CardDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class AddCard implements Command<CardDto> {

	CardDto dto;
	PaymentMeanRepository pr=Factory
			.repository.forPaymentMean();
	ClientRepository cr=Factory
			.repository.forClient();
	CreditCardRepository ccr=Factory
			.repository.forCreditCard();
	
	public AddCard(CardDto card) {
		ArgumentChecks.isNotNull(card);
		ArgumentChecks.isNotNull(card.id);
		ArgumentChecks.isNotNull(card.cardExpiration);
		ArgumentChecks.isNotNull(card.cardNumber);
		ArgumentChecks.isNotNull(card.cardType);
		ArgumentChecks.isNotNull(card.clientId);
		ArgumentChecks.isNotEmpty(card.id);
		ArgumentChecks.isNotEmpty(card.cardNumber);
		ArgumentChecks.isNotEmpty(card.cardType);
		ArgumentChecks.isNotEmpty(card.clientId);
		this.dto=card;
	}


	@Override
	public CardDto execute() throws BusinessException {
		Optional<Client> exist=cr.findById(dto.clientId);
		BusinessChecks.isFalse(exist.isEmpty());
		BusinessChecks.isTrue(dto.cardExpiration
				.isAfter(LocalDate.now()));
		Optional<PaymentMean> rep=ccr.findByCardNumber(dto.cardNumber);
		BusinessChecks.isTrue(rep.isEmpty());
		CreditCard card=new CreditCard(exist.get(),
				dto.cardNumber,dto.cardType,dto.cardExpiration);
		ccr.add(card);
		pr.add(card);
		this.dto.id=card.getId();
		return dto;
	}

}
