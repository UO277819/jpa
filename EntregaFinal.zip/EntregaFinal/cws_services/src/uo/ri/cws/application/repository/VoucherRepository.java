package uo.ri.cws.application.repository;

import java.util.Optional;

import uo.ri.cws.domain.Voucher;

public interface VoucherRepository 
extends Repository<Voucher>{

	Optional<Voucher> findByCode(String code);

}
