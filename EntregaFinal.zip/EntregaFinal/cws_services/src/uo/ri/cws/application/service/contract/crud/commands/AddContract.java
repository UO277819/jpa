package uo.ri.cws.application.service.contract.crud.commands;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.ContractType;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.cws.domain.Contract.ContractState;
import uo.ri.util.assertion.ArgumentChecks;

public class AddContract implements Command<ContractDto> {

	private ContractDto dto;
	ContractRepository cr=Factory
		.repository
		.forContract();
	ContractTypeRepository ctr=Factory
		.repository
		.forContractType();
	ProfessionalGroupRepository pgr=Factory
		.repository
		.forProfessionalGroup();
	MechanicRepository mr=Factory
		.repository
		.forMechanic();

	public AddContract(ContractDto c) {
		ArgumentChecks.isNotNull(c);
		ArgumentChecks.isNotNull(c.professionalGroupName);
		ArgumentChecks.isNotNull(c.contractTypeName);
		ArgumentChecks.isNotNull(c.professionalGroupName);
		ArgumentChecks.isNotNull(c.contractTypeName);
		if(c.contractTypeName=="FIXED_TERM")
			ArgumentChecks.isNotNull(c.endDate);
		ArgumentChecks.isTrue(c.annualBaseWage>0);
		ArgumentChecks.isNotNull(c.dni);
		ArgumentChecks.isNotNull(c.id);
		ArgumentChecks.isNotEmpty(c.dni);
		ArgumentChecks.isNotEmpty(c.id);
		ArgumentChecks.isNotBlank(c.dni);
		ArgumentChecks.isNotBlank(c.id);
		this.dto=c;
	}

	@Override
	public ContractDto execute() throws BusinessException {
		if(dto.endDate!=null) {
			BusinessChecks
			.isTrue(dto.startDate
			.isBefore(dto.endDate));
		}
		Optional<ProfessionalGroup> existpg=pgr
			.findByName(dto.professionalGroupName);
		BusinessChecks.isTrue(existpg.isPresent());
		Optional<ContractType> existct=ctr
			.findByName(dto.contractTypeName);
		BusinessChecks.isTrue(existct.isPresent());
		Optional<Mechanic> existm=mr
			.findByDni(dto.dni);
		BusinessChecks.isTrue(existm.isPresent());
		List<Contract> lista=cr
			.findByMechanicId(existm.get().getId());
		for(Contract c:lista) {
			if(c.getState()==ContractState.IN_FORCE) {
				c.terminate();
				c.setEndDate(LocalDate
					.now()
					.with(TemporalAdjusters
						.lastDayOfMonth()));
				c.setSettlement(c
					.calcularLiquidaciuon());
			}
			
		}
		Contract contract=new Contract(existm
			.get(),existct.get(),
			existpg.get(),dto.endDate
			,dto.annualBaseWage);
		this.dto.id=contract.getId();
		cr.add(contract);
		return dto;
	}

}
