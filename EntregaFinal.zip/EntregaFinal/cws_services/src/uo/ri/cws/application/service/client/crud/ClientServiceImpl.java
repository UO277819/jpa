package uo.ri.cws.application.service.client.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService;

public class ClientServiceImpl implements ClientCrudService {

	//private CommandExecutor executor = Factory.executor.forExecutor();

	@Override
	public ClientDto addClient(ClientDto client) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteClient(String idClient) throws BusinessException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateClient(ClientDto client) throws BusinessException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ClientDto> findAllClients() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ClientDto> findClientById(String idClient) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}
