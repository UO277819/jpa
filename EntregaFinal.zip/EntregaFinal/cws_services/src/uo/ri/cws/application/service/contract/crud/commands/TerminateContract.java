package uo.ri.cws.application.service.contract.crud.commands;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Contract.ContractState;
import uo.ri.util.assertion.ArgumentChecks;

public class TerminateContract implements Command<Void> {

	private String id;
	ContractRepository cr=Factory
		.repository
		.forContract();
	
	public TerminateContract(String contractId) {
		ArgumentChecks.isNotNull(contractId);
		ArgumentChecks.isNotEmpty(contractId);
		ArgumentChecks.isNotBlank(contractId);
		this.id=contractId;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Contract> existc=cr.findById(id);
		BusinessChecks.isTrue(existc.isPresent());
		Contract c=existc.get();
		BusinessChecks.isTrue(c.getState()
			==
			ContractState.IN_FORCE);
		c.terminate();
		c.setEndDate(LocalDate.now()
			.with(TemporalAdjusters
				.lastDayOfMonth()));
		c.setSettlement(c.calcularLiquidaciuon());
		return null;
	}

}
