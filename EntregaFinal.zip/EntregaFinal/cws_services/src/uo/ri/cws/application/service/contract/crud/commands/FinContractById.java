package uo.ri.cws.application.service.contract.crud.commands;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.util.assertion.ArgumentChecks;

public class FinContractById implements Command<Optional<ContractDto>> {

	private String id;
	ContractRepository cr=Factory
		.repository
		.forContract();

	public FinContractById(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id=id;
	}

	@Override
	public Optional<ContractDto> execute() throws BusinessException {
		Optional<Contract> exist=cr.findById(id);
		if(exist.isEmpty()) {
			return Optional
				.ofNullable(null);
		}
		Contract c=exist.get();
		ContractDto dto=DtoAssembler.toDto(c);
		dto.endDate=LocalDate
			.now()
			.with(TemporalAdjusters
				.lastDayOfMonth());
		return Optional.ofNullable(dto);
	}

}
