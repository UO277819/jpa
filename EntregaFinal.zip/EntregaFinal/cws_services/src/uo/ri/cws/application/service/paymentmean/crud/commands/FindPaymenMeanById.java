package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.PaymentMeanDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class FindPaymenMeanById
implements Command<Optional<PaymentMeanDto>> {

	private String id;
	PaymentMeanRepository pay=Factory
			.repository.forPaymentMean();

	public FindPaymenMeanById(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id=id;
	}

	@Override
	public Optional<PaymentMeanDto> execute() 
		throws BusinessException {
		Optional<PaymentMean> exist=pay.findById(id);
		if(exist.isEmpty())
			return Optional.empty();
		PaymentMean m=exist.get();
		PaymentMeanDto dto=DtoAssembler.toDto(m);
		return Optional.ofNullable(dto);
	}

}
