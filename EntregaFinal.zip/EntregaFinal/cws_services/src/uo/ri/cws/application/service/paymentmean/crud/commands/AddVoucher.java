package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.repository.VoucherRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.VoucherDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.Voucher;
import uo.ri.util.assertion.ArgumentChecks;

public class AddVoucher implements Command<VoucherDto> {

	VoucherDto dto;
	PaymentMeanRepository pr=Factory
			.repository.forPaymentMean();
	ClientRepository cr=Factory
			.repository.forClient();
	VoucherRepository vr=Factory
			.repository.forVoucher();
	public AddVoucher(VoucherDto voucher) {
		ArgumentChecks.isNotNull(voucher);
		ArgumentChecks.isNotNull(voucher.code);
		ArgumentChecks.isNotNull(voucher.description);
		ArgumentChecks.isNotNull(voucher.clientId);
		ArgumentChecks.isNotEmpty(voucher.code);
		ArgumentChecks.isNotEmpty(voucher.description);
		ArgumentChecks.isNotEmpty(voucher.clientId);
		this.dto=voucher;
	}

	@Override
	public VoucherDto execute() throws BusinessException {
		Optional<Client> exist=cr.findById(dto.clientId);
		BusinessChecks.isFalse(exist.isEmpty());
		BusinessChecks.isTrue(vr.findByCode(dto.code).isEmpty());
		Voucher v=new Voucher(exist.get(),dto.code,
				dto.description,dto.balance);
		vr.add(v);
		pr.add(v);
		dto.id=v.getId();
		return dto;
	}

}
