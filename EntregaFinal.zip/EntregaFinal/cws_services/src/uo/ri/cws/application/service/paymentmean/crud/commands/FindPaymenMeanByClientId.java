package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.PaymentMeanDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class FindPaymenMeanByClientId
implements Command<List<PaymentMeanDto>> {

	private String id;

	PaymentMeanRepository pay=Factory
			.repository.forPaymentMean();
	ClientRepository cr=Factory
			.repository.forClient();
	
	public FindPaymenMeanByClientId(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);
		this.id=id;
	}

	@Override
	public List<PaymentMeanDto> execute()
		throws BusinessException {
		Optional<Client> exist=cr.findById(id);
		BusinessChecks.isTrue(exist.isPresent());
		Set<PaymentMean> lista=exist.get().getPaymentMeans();
		List<PaymentMeanDto> result=new ArrayList<>();
		for(PaymentMean p:lista) {
			result.add(DtoAssembler.toDto(p));
		}
		return result;
	}

}
