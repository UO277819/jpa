package uo.ri.cws.application.service.contract.crud.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractSummaryDto;

import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Mechanic;
import uo.ri.util.assertion.ArgumentChecks;

public class FindByMechanic 
implements Command<List<ContractSummaryDto>> {

	private String mechanicDni;
	ContractRepository cr=Factory
		.repository
		.forContract();
	MechanicRepository mr=Factory
		.repository
		.forMechanic();
	
	public FindByMechanic(String mechanicDni) {
		ArgumentChecks.isNotNull(mechanicDni);
		ArgumentChecks.isNotEmpty(mechanicDni);
		this.mechanicDni=mechanicDni;
	}

	@Override
	public List<ContractSummaryDto> execute() throws BusinessException {
		Optional<Mechanic> exist=mr
			.findByDni(mechanicDni);
		if(exist.isEmpty()) {
			return new ArrayList<>();
		}
		List<ContractSummaryDto> result=new ArrayList<>();
		for(Contract cont:exist.get()
			.getTerminatedContracts()) {
			result
			.add(DtoAssembler
				.toSummaryDto(cont));
		}
		if(exist.get()
			.getContractInForce()
			.isPresent()) {
			result.add(DtoAssembler
				.toSummaryDto(exist.get()
					.getContractInForce()
					.get()));
		}
		return result;
	}

}
