package uo.ri.cws.domain;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tsubstitutions", uniqueConstraints 
= @UniqueConstraint(columnNames = {
	"intervention_id", "sparePart_id" }))
public class Substitution extends BaseEntity {
    // natural attributes
    private int quantity;

    // accidental attributes
    @ManyToOne(optional = false)
    private SparePart sparePart;
    @ManyToOne(optional = false)
    private Intervention intervention;

    public Substitution() {
		// TODO Auto-generated constructor stub
	}
    
    public Substitution(SparePart sp, Intervention intervention2,
	    int cantidad) {
		// TODO Auto-generated constructor stub
		ArgumentChecks.isNotNull(sp);
		ArgumentChecks.isNotNull(intervention2);
		ArgumentChecks.isTrue(cantidad > 0);
		Associations.Substitute.link(sp, this, intervention2);
		this.quantity=cantidad;
    }

    public double getAmount() {
		return quantity * sparePart.getPrice();
	}
	
	public int getQuantity() {
		return quantity;
	}

	public SparePart getSparePart() {
		return sparePart;
	}

	public Intervention getIntervention() {
		return intervention;
	}

	void _setSparePart(SparePart sparePart) {
		this.sparePart = sparePart;
	}

	void _setIntervention(Intervention intervention) {
		this.intervention = intervention;
	}
	
	SparePart _getSparePart() {
		return sparePart;
	}

	Intervention _getIntervention() {
		return intervention;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(intervention, sparePart);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Substitution other = (Substitution) obj;
		return Objects.equals(intervention, other.intervention) && Objects.equals(sparePart, other.sparePart);
	}

}
