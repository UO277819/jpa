package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name ="tcontractTypes")
public class ContractType extends BaseEntity{
	@Column(unique = true)
    @Basic(optional = false)
	private String name;
	private double compensationdays;
	
	@OneToMany(mappedBy = "contractType")
	private Set<Contract> contracts=new HashSet<>();

	public ContractType() {
		// TODO Auto-generated constructor stub
	}
	
	public ContractType(String string, double compensationDays) {
		ArgumentChecks.isNotNull(string);
		ArgumentChecks.isNotBlank(string);
		ArgumentChecks.isNotEmpty(string);
		ArgumentChecks.isTrue(compensationDays>0);
		this.name=string;
		this.compensationdays=compensationDays;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCompensationDays() {
		return compensationdays;
	}

	public void setCompensationdays(double compensationdays) {
		this.compensationdays = compensationdays;
	}

	public Set<Contract> getContracts() {
		return new HashSet<>(contracts);
	}
	
	public Set<Contract> _getContracts() {
		return (contracts);
	}

	public void _setContracts(Set<Contract> contracts) {
		this.contracts = contracts;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContractType other = (ContractType) obj;
		return Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "ContractType [name=" + name + ", compensationdays=" + compensationdays + "]";
	}

	
	
	
}
