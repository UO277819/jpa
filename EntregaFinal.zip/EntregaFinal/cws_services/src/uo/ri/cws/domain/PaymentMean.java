package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.*;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tpaymentMeans")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class PaymentMean extends BaseEntity {
	// natural attributes
	@Basic(optional=false)
	protected double accumulated = 0.0;

	// accidental attributes
	@JoinColumn(name="client_id")
	@ManyToOne
	protected Client client;
	@OneToMany(mappedBy="paymentMean")
	protected Set<Charge> charges = new HashSet<>();

    public PaymentMean() {
    }

    public PaymentMean(Client cliente) {
		ArgumentChecks.isNotNull(cliente);
		Associations.Pay.link( cliente,this);
	}
    
    public double getAccumulated() {
		return accumulated;
	}

	public Client getClient() {
		return client;
	}

	public void pay(double importe) {
		this.accumulated += importe;
	}

	void _setClient(Client client) {
		this.client = client;
	}

	public Set<Charge> getCharges() {
		return new HashSet<>( charges );
	}

	Set<Charge> _getCharges() {
		return charges;
	}

	@Override
	public int hashCode() {
		return Objects.hash(client);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PaymentMean other = (PaymentMean) obj;
		return Objects.equals(client, other.client);
	}

}
