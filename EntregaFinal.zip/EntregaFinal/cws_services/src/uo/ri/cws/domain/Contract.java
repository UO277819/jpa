package uo.ri.cws.domain;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.TemporalAdjusters;
import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;
import uo.ri.util.math.Round;
@Entity
@Table(name = "tcontracts", uniqueConstraints = @UniqueConstraint(columnNames = {
	"startdate", "mechanic_id" }))
public class Contract extends BaseEntity{
	 public enum ContractState {
		 IN_FORCE, TERMINATED
		    }
	@Column(unique = true)
    @Basic(optional = false)
	private LocalDate startdate;
	private LocalDate endDate;
	@Column(name="AnnualBaseWage")
	private double annualWage;
	@Enumerated(EnumType.STRING)
	private ContractState state;
	private double settlement;//liquidacion
	
	@ManyToOne(optional = false)
	private Mechanic mechanic;
	@ManyToOne(optional = false)
	private Mechanic firedMechanic;
	@ManyToOne(optional = false)
	private ContractType contractType;
	@ManyToOne(optional = false)
	private ProfessionalGroup professionalGroup;
	@OneToMany(mappedBy = "contract")
	private  Set<Payroll> payrolls=new HashSet<>();
	
	Contract(){
		
	}
	public Contract(Mechanic mechanic, ContractType type, ProfessionalGroup group, LocalDate endDate, double wage) {
		ArgumentChecks.isNotNull(mechanic);
		ArgumentChecks.isNotNull(type);
		ArgumentChecks.isNotNull(group);
		if(type.getName().equals("FIXED_TERM"))
			ArgumentChecks.isNotNull(endDate);
		if(endDate==null) {
			endDate=LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
		}
		ArgumentChecks.isTrue(wage>=0);
		this.startdate=LocalDate.now().with(TemporalAdjusters.firstDayOfNextMonth());
		this.annualWage=wage;
		this.endDate=endDate;
		this.state=ContractState.IN_FORCE;
		firedMechanic=mechanic;
		//Associations.Fire.link(this);
		this.mechanic=mechanic;
		this.professionalGroup=group;
		this.contractType=type;
		this.settlement=calcularLiquidaciuon();
		Associations.Hire.link(mechanic, this);
		Associations.Group.link(group, this);
		Associations.Type.link(type, this);
		
		
	}


	public double calcularLiquidaciuon() {
		if(endDate!=null) {
			Period p=Period.between(startdate, endDate);
			if(state==ContractState.TERMINATED &&
					p.getYears()>=1) {
				double t=calcularTrienio();
				double prod=calcularProductividad();
				double a=Round.twoCents((annualWage
						+t
						+prod)/365);
				double b=contractType.getCompensationDays();
				double c=p.getYears();
				return  Round.twoCents(a*b*c);
			}
		}
		return 0.0;
	}


	private double calcularProductividad() {
		double result=0.0;
		Period p=null;
		for(Payroll pay:getPayrolls()) {
			p=Period.between(pay.getDate(), endDate);
			if(p.getYears()<=0)
				result+=pay.getProductivityBonus();
		}
		return result;
	}


	public Contract(Mechanic mechanic2, ContractType type, ProfessionalGroup group, double wage) {
		this(mechanic2,type,group,LocalDate.now()
				.plusMonths(1).with(TemporalAdjusters.lastDayOfMonth())
				,wage);
	}

	
	
	public void setSettlement(double settlement) {
		this.settlement = settlement;
	}
	private double calcularTrienio() {
		double result=0.0;
		Period p=null;
		for(Payroll pay:getPayrolls()) {
			p=Period.between(pay.getDate(), endDate);
			if(p.getYears()<=0)
			result+=pay.getTrienniumPayment();
		}
		return result;
	}
	
	public LocalDate getStartDate() {
		return startdate;
	}


	public void setStartDate(LocalDate startdate) {
		this.startdate = startdate;
	}


	public Optional<LocalDate> getEndDate() {
		return Optional.ofNullable(endDate);
	}


	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}


	public double getWage() {
		return annualWage;
	}


	public void setWage(double wage) {
		this.annualWage = wage;
	}


	public Optional<Mechanic> getMechanic() {
		return Optional.ofNullable(mechanic);
	}


	public void _setMechanic(Mechanic mechanic) {
		this.mechanic = mechanic;
	}

	

	public ContractState getState() {
		return state;
	}


	public void setState(ContractState state) {
		this.state = state;
	}


	public ContractType getContractType() {
		return contractType;
	}


	public void _setContractType(ContractType contractType) {
		this.contractType = contractType;
	}


	public ProfessionalGroup getProfessionalGroup() {
		return professionalGroup;
	}


	public void _setProfessionalGroup(ProfessionalGroup professionalGroup) {
		this.professionalGroup = professionalGroup;
	}


	public Set<Payroll> _getPayrolls() {
		return payrolls;
	}

	public Set<Payroll> getPayrolls() {
		return new HashSet<>(payrolls);
	}

	
	public void _setPayrolls(Set<Payroll> payrolls) {
		this.payrolls = payrolls;
	}


	@Override
	public int hashCode() {
		return Objects.hash(mechanic, startdate);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contract other = (Contract) obj;
		return Objects.equals(mechanic, other.mechanic) && Objects.equals(startdate, other.startdate);
	}


	@Override
	public String toString() {
		return "Contract [startdate=" + startdate + ", endDate=" + endDate + ", wage=" + annualWage + "]";
	}


	public double getAnnualBaseWage() {
		return annualWage;
	}


	public double getSettlement() {
		this.settlement=calcularLiquidaciuon();
		return settlement;
	}


	public void terminate() {
		this.state=ContractState.TERMINATED;
		setFiredMechanic(mechanic);
		Associations.Hire.unlink(this,mechanic);
		Associations.Fire.link(this);
	}


	public Optional<Mechanic> getFiredMechanic() {
		return Optional.ofNullable(firedMechanic);
	}
	public void setFiredMechanic(Mechanic m) {
		this.firedMechanic=m;
	}

	public void _setFiredMechanic(Mechanic m) {
		this.firedMechanic=m;
	}
	public Mechanic _getFiredMechanic() {
		return firedMechanic;
	}


	public Mechanic _getMechanic() {
		return mechanic;
	}
	public boolean existEndDate() {
		if(endDate==null)
			return false;
		return true;
	}


}
