package uo.ri.cws.domain;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Objects;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import uo.ri.cws.domain.WorkOrder.WorkOrderState;
import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name ="tpayrolls", uniqueConstraints = @UniqueConstraint(columnNames = {
		"date", "contract_id" }))
public class Payroll extends BaseEntity{
	@Column(unique = true)
    @Basic(optional = false)
	private LocalDate date;
	private double bonus;
	private double incomeTax;
	private double monthlyWage;
	private double nic;
	private double productivityBonus;
	private double trienniumPayment;
	
	@ManyToOne(optional=false)
	private Contract contract;

	public Payroll() {
		// TODO Auto-generated constructor stub
	}
	
	public Payroll(Contract object) {
		this(object,LocalDate.now());
	}

	public Payroll(Contract contract2, LocalDate d) {
		ArgumentChecks.isNotNull(contract2);
		ArgumentChecks.isNotNull(d);
		this.date=d;
		this.monthlyWage=contract2.getAnnualBaseWage()/14;
		this.bonus=calcularBonus();
		this.productivityBonus=calcularProductividad(contract2);
		this.trienniumPayment=calcularTrienio(contract2);
		this.incomeTax=calcularTax(contract2 );
		this.nic=CalcularNic(contract2);
		
		Associations.Run.link(this, contract2);
	}

	private double calcularProductividad(Contract contract2) {
		double result=0.0;
		for(WorkOrder work:contract2.getMechanic()
				.get().getAssigned()) {
			if(work.getState()==WorkOrderState.INVOICED) {
				if(work.getDate().getMonth()
						==date.getMonth()) {
					result+=work.getAmount();
				}
			}
		}
		return result*contract2
				.getProfessionalGroup()
				.getProductivityBonusPercentage()/100;
	}

	private double calcularTrienio(Contract contract2) {
		Period period = Period.between(contract2.getStartDate(), date);
		int cantidad=period.getYears()/3;
		return contract2.getProfessionalGroup()
				.getTrienniumPayment()*cantidad;
	}

	public Payroll(Contract contract2, LocalDate d, double monthlyWage, double extra, double productivity,
			double trienniums, double tax, double nic2) {
		ArgumentChecks.isNotNull(contract2);
		ArgumentChecks.isNotNull(d);
		this.date=d;
		this.monthlyWage=monthlyWage;
		this.bonus=extra;
		this.productivityBonus=productivity;
		this.trienniumPayment=trienniums;
		this.incomeTax=tax;
		this.nic=nic2;
		
		Associations.Run.link(this, contract2);
	}

	private double CalcularNic(Contract contract2) {
		return Math.floor(((contract2.getAnnualBaseWage() * 0.05) / 12) * 100) / 100;
	}
	
	private double calcularBonus() {
		if(date.getMonth().equals(Month.JUNE) ||
				date.getMonth().equals(Month.DECEMBER))
			return monthlyWage;
		return 0.0;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public double getIncomeTax() {
		return incomeTax;
	}

	public Double calcularTax(Contract contract2) {
		double rate=0.0;
		double anual=contract2.getAnnualBaseWage();
		if(anual<12450)
			rate=0.19;
		else if(anual<20200)
			rate=0.24;
		else if(anual<35200)
			rate=0.30;
		else if(anual<60000)
			rate=0.37;
		else if(anual<300000)
			rate=0.45;
		else
			rate=0.47;
		return (monthlyWage+bonus
				+trienniumPayment
				+productivityBonus)
				*rate;
	}
	
	public void setIncomeTax(double incomeTax) {
		this.incomeTax = incomeTax;
	}

	public double getNic() {
		return nic;
	}

	public void setNic(double nic) {
		this.nic = nic;
	}

	public double getProductivityBonus() {
		return productivityBonus;
	}

	public void setProductivityBonus(double productivityBonus) {
		this.productivityBonus = productivityBonus;
	}

	public double getTrienniumPayment() {
		return trienniumPayment;
	}

	public void setTrienniumPayment(double trienniumPayment) {
		this.trienniumPayment = trienniumPayment;
	}

	public Contract _getContract() {
		return contract;
	}

	public void _setContract(Contract contract) {
		this.contract = contract;
	}

	@Override
	public int hashCode() {
		return Objects.hash(contract, date);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payroll other = (Payroll) obj;
		return Objects.equals(contract, other.contract) && Objects.equals(date, other.date);
	}

	@Override
	public String toString() {
		return "Payroll [date=" + date + ", bonus=" + bonus + ", incomeTax=" + incomeTax + ", nic=" + nic
				+ ", productivityBonus=" + productivityBonus + ", trienniumPayment=" + trienniumPayment + "]";
	}

	public Contract getContract() {
		return contract;
	}

	public Double getMonthlyWage() {
		return monthlyWage;
	}

	public Double getNIC() {
		return nic;
	}
	
	
	

}
