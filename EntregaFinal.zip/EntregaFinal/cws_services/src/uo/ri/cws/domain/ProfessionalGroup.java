package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name ="tprofessionalGroups")
public class ProfessionalGroup extends BaseEntity{
	@Column(unique = true)
    @Basic(optional = false)
	private String name;
	@Column(name="PRODUCTIVITYBONUSPERCENTAGE")
	private double productivityRate;
	@Column(name="trienniumPayment")
	private double trienniumSalary;
	
	@OneToMany(mappedBy = "professionalGroup")
	private Set<Contract> contracts=new HashSet<>();

	public ProfessionalGroup() {
		// TODO Auto-generated constructor stub
	}
	
	public ProfessionalGroup(String string, double d, double e) {
		ArgumentChecks.isNotBlank(string);
		ArgumentChecks.isNotEmpty(string);
		ArgumentChecks.isTrue(d>=0);
		ArgumentChecks.isTrue(e>=0);
		
		this.name=string;
		this.productivityRate=e;
		this.trienniumSalary=d;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getProductivityRate() {
		return productivityRate;
	}

	public void setProductivityRate(double productivityRate) {
		this.productivityRate = productivityRate;
	}

	public double getTrienniumSalary() {
		return trienniumSalary;
	}

	public void setTrienniumSalary(double trienniumSalary) {
		this.trienniumSalary = trienniumSalary;
	}

	public Set<Contract> getContracts() {
		return new HashSet<>(contracts);
	}

	public Set<Contract> _getContracts() {
		return (contracts);
	}
	
	public void _setContracts(Set<Contract> contracts) {
		this.contracts = contracts;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfessionalGroup other = (ProfessionalGroup) obj;
		return Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "ProfessionalGroup [name=" + name + ", productivityRate=" + productivityRate + ", trienniumSalary="
				+ trienniumSalary + "]";
	}

	public double getProductivityBonusPercentage() {
		return productivityRate;
	}

	public double getTrienniumPayment() {
		return trienniumSalary;
	}

	
	
}
