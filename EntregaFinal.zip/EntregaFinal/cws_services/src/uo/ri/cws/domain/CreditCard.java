package uo.ri.cws.domain;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tcreditCards")
public class CreditCard extends PaymentMean {
    @Column(unique = true)
    @Basic(optional = false)
    private String number;
    @Basic(optional=false)
	private String type;
	@Basic(optional=false)
    private LocalDate validThru;

	CreditCard(){
	}
	
	public CreditCard(Client client,String number, String type, LocalDate date) {
		super(client);
		ArgumentChecks.isNotEmpty(number);
		ArgumentChecks.isNotEmpty(type);
		ArgumentChecks.isNotNull(date);
		
		this.number=number;
		this.type=type;
		this.validThru = LocalDate.from(date);
		
	}
	
	public CreditCard(String number, String type, LocalDate date) {
		ArgumentChecks.isNotEmpty(number);
		ArgumentChecks.isNotEmpty(type);
		ArgumentChecks.isNotNull(date);
		
		this.number=number;
		this.type=type;
		this.validThru = LocalDate.from(date);
		
	}
	
	public CreditCard(Client client,String number) {
		this(client,number, "UNKNOWN", LocalDate.now().plusDays(1));
	}
	
	public CreditCard(String number) {
		this(number, "UNKNOWN", LocalDate.now().plusDays(1));
	}
	
	public boolean isValidNow() {
		return validThru.isAfter(LocalDate.now());
	}
	
	public void pay(double importe) {
		if(isValidNow())
			this.accumulated += importe;
		else
			throw new IllegalStateException();
				
	}
	public String getNumber() {
		return number;
	}

	public String getType() {
		return type;
	}

	public LocalDate getValidThru() {
		return validThru;
	}

	public void setValidThru(LocalDate validThru) {
		this.validThru = validThru;
	}

	@Override
	public int hashCode() {
		return Objects.hash(number);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCard other = (CreditCard) obj;
		return Objects.equals(number, other.number);
	}
}