package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.VoucherRepository;
import uo.ri.cws.domain.Voucher;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class VoucherJpaRepository
extends BaseJpaRepository<Voucher> 
implements VoucherRepository{

	@Override
	public Optional<Voucher> findByCode(String code) {
		List<Voucher> result = Jpa.getManager()
				.createNamedQuery("Voucher.findByCode", 
						Voucher.class).setParameter(1, code)
				.getResultList();
		
		if(result.isEmpty())
			return Optional.empty();
		
		return Optional.ofNullable(result.get(0));
	}
}
