package uo.ri.cws.infrastructure.persistence.jpa.repository;

import uo.ri.cws.application.repository.CashRepository;
import uo.ri.cws.domain.Cash;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;

public class CashJpaRepository	
extends BaseJpaRepository<Cash> 
implements CashRepository {

}
