package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class InvoiceJpaRepository 
		extends BaseJpaRepository<Invoice>
		implements InvoiceRepository {

	@Override
	public Optional<Invoice> findByNumber(Long numero) {
		List<Invoice> result = Jpa.getManager()
				.createNamedQuery("Invoice.findByNumber",
						Invoice.class)
				.setParameter(1,numero).getResultList();	
		if(result.isEmpty())
			return Optional.empty();
		return Optional.ofNullable(result.get(0));
	}

	@Override
	public Long getNextInvoiceNumber() {
		List<Invoice> result = Jpa.getManager()
				.createNamedQuery("Invoice.getNextInvoiceNumber",
						Invoice.class).getResultList();
		if(result.isEmpty() ||
				result.get(0) == null)
			return 1L;
		return result.get(0).getNumber();
	}

}
