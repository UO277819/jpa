package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.CreditCardRepository;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class CreditCardJpaRepository 
	extends BaseJpaRepository<CreditCard> 
	implements CreditCardRepository {

	@Override
	public Optional<PaymentMean> findByCardNumber(String cardNumber) {
		List<PaymentMean> result = Jpa.getManager()
				.createNamedQuery("CreditCard.findByCardNumber", 
						PaymentMean.class).setParameter(1, cardNumber)
				.getResultList();
		
		if(result.isEmpty())
			return Optional.empty();
		
		return Optional.ofNullable(result.get(0));
	}


}

