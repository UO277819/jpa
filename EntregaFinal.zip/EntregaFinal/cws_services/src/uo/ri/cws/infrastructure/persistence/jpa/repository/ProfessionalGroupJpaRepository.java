package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class ProfessionalGroupJpaRepository 
extends BaseJpaRepository<ProfessionalGroup>
implements ProfessionalGroupRepository{

	@Override
	public Optional<ProfessionalGroup> findByName(String name) {
		List<ProfessionalGroup> result = Jpa.getManager()
				.createNamedQuery("ProfessionalGroup.findByName",
						ProfessionalGroup.class).setParameter(1, name).
						getResultList();
		if(result.isEmpty())
			return Optional.empty();
		return Optional.ofNullable(result.get(0));
	}

}
