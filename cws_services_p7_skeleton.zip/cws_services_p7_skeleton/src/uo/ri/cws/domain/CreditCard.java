package uo.ri.cws.domain;

import java.time.LocalDate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tcreditCards")
public class CreditCard extends PaymentMean {
    @Column(unique = true)
    @Basic(optional = false)
    private String number;
    private String type;
    private LocalDate validThru;

}
