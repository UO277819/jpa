package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tclients")
public class Client extends BaseEntity {
    /*
     * Atributos naturales
     */
    @Column(unique = true, nullable = false)
    private String dni;// identidad natural
    private String name;
    private String surname;
    private String email;
    private String phone;
    private Address address;
    @OneToMany(mappedBy = "client")
    private Set<Vehicle> vehicles = new HashSet<Vehicle>();
    @OneToMany(mappedBy = "client")
    private Set<PaymentMean> paymentMeans = new HashSet<PaymentMean>();

    public Client() {

    }

    public Client(String d, String n, String e) {
	ArgumentChecks.isNotEmpty(d);
	ArgumentChecks.isNotEmpty(n);
	ArgumentChecks.isNotEmpty(e);
	ArgumentChecks.isNotBlank(d);
	ArgumentChecks.isNotBlank(n);
	ArgumentChecks.isNotBlank(e);

	this.dni = d;
	this.name = n;
	this.surname = e;
    }

    public String getDni() {
	return dni;
    }

    public String getName() {
	return name;
    }

    public String getSurname() {
	return surname;
    }

    public String getEmail() {
	return email;
    }

    public String getPhone() {
	return phone;
    }

    public Address getAddress() {
	return address;
    }

    public Set<Vehicle> getVehicles() {
	return new HashSet<>(vehicles);
    }

    Set<Vehicle> _getVehicles() {
	return vehicles;
    }

    @Override
    public int hashCode() {
	return Objects.hash(dni);
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Client other = (Client) obj;
	return Objects.equals(dni, other.dni);
    }

    @Override
    public String toString() {
	return "Client [dni=" + dni + ", name=" + name + ", surname=" + surname
		+ ", email=" + email + ", phone=" + phone + ", address="
		+ address + "]";
    }

}
