package uo.ri.cws.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.*;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tinterventions", uniqueConstraints = @UniqueConstraint(columnNames = {
	"date", "vehicle_id" }))
public class Intervention extends BaseEntity {
	// natural attributes
		@Basic(optional=false)
		private LocalDateTime date;
		@Basic(optional=false)
		private int minutes;

		// accidental attributes
		@ManyToOne
		private WorkOrder workOrder;
		@ManyToOne
		private Mechanic mechanic;
		@OneToMany(mappedBy="intervention")
		private Set<Substitution> substitutions = new HashSet<>();

    public Intervention() {
    }

    public Intervention(Mechanic mechanic2, WorkOrder workOrder2, int min) {
    	ArgumentChecks.isNotNull(mechanic2);
    	ArgumentChecks.isNotNull(workOrder2);
		ArgumentChecks.isTrue(min>=0);
		
		//this.date = date.truncatedTo(ChronoUnit.MILLIS);
		this.date=LocalDateTime.now();
		this.minutes = min;
		this.workOrder = workOrder2;
		this.mechanic = mechanic2;
		
		Associations.Intervene.link(workOrder, this, mechanic);
    }

    void _setWorkOrder(WorkOrder workOrder) {
	this.workOrder = workOrder;
    }

    void _setMechanic(Mechanic mechanic) {
	this.mechanic = mechanic;
    }

    public Set<Substitution> getSubstitutions() {
	return new HashSet<>(substitutions);
    }

    Set<Substitution> _getSubstitutions() {
	return substitutions;
    }

    public LocalDateTime getDate() {
	return date;
    }

    public int getMinutes() {
	return minutes;
    }

    public WorkOrder getWorkOrder() {
	return workOrder;
    }

    public Mechanic getMechanic() {
	return mechanic;
    }

    @Override
    public String toString() {
	return "Intervention [date=" + date + ", minutes=" + minutes + "]";
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(date, mechanic, workOrder);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Intervention other = (Intervention) obj;
		return Objects.equals(date, other.date) && Objects.equals(mechanic, other.mechanic)
				&& Objects.equals(workOrder, other.workOrder);
	}
    
    public double getAmount() {
		double amount = 0.0;
		for (Substitution substitution : substitutions) {
			amount += substitution.getAmount();
		}
		amount += workOrder.getVehicle().getVehicleType().getPricePerHour()
				* this.minutes/60;
		return amount;
	}

	public WorkOrder _getWorkOrder() {
		return workOrder;
	}

	public Mechanic _getMechanic() {
		return mechanic;
	}

}
