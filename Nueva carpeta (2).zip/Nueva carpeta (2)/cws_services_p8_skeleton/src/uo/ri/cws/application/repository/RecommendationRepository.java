package uo.ri.cws.application.repository;

import uo.ri.cws.domain.Recommendation;

public interface RecommendationRepository extends Repository<Recommendation> {

}
