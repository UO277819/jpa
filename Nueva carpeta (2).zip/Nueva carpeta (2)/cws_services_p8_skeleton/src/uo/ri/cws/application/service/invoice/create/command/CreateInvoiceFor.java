package uo.ri.cws.application.service.invoice.create.command;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoiceDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.cws.domain.WorkOrder.WorkOrderState;
import uo.ri.util.assertion.ArgumentChecks;

public class CreateInvoiceFor implements Command<InvoiceDto>{

	private List<String> workOrderIds;
	private WorkOrderRepository wrkrsRepo = Factory.repository.forWorkOrder();
	private InvoiceRepository invsRepo = Factory.repository.forInvoice();

	public CreateInvoiceFor(List<String> workOrderIds) {
		ArgumentChecks.isNotNull(workOrderIds);
		ArgumentChecks.isTrue(!workOrderIds.isEmpty());
		for (String string : workOrderIds) {
			ArgumentChecks.isNotNull(string);
			ArgumentChecks.isNotEmpty(string);
		}
		this.workOrderIds = workOrderIds;
		
	}

	@Override
	public InvoiceDto execute() throws BusinessException {
		List<WorkOrder> workorders = new ArrayList<>();
		
		for (String string : workOrderIds) {
			Optional<WorkOrder> res = wrkrsRepo.findById(string);
			BusinessChecks.isTrue(!res.isEmpty(), "param invalido");
			BusinessChecks.isTrue(res.get().getState().equals(WorkOrderState.FINISHED), "param invalido");
			workorders.add(res.get());
		}
		
		long numberInvoice = invsRepo.getNextInvoiceNumber();
		LocalDate dateInvoice = LocalDate.now();
		
		Invoice i = new Invoice(numberInvoice,dateInvoice, workorders);
		invsRepo.add(i);
		return DtoAssembler.toDto(i);
	}

	
}
