package uo.ri.cws.application.service.client.crud.command;

import java.util.Optional;

import alb.util.assertion.ArgumentChecks;
import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Address;
import uo.ri.cws.domain.Client;

public class UpdateClient implements Command<Void>{

	public ClientDto dto;
	private ClientRepository cRepo = Factory.repository.forClient();
	
	public UpdateClient(ClientDto dto) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotNull(dto.id);
		ArgumentChecks.isNotEmpty(dto.id);
		this.dto = dto;
	}
	
	@Override
	public Void execute() throws BusinessException {
		Optional<Client> cliente = cRepo.findById(dto.id);
		BusinessChecks.isTrue(!cliente.isEmpty(), "Cliente no existe");
		Client c=cliente.get();
		c.setEmail(dto.email);
		c.setName(dto.name);
		c.setSurname(dto.surname);
		c.setPhone(dto.phone);
		c.setAddress(new Address(dto.addressStreet,dto.addressCity,dto.addressZipcode));
		return null;
	}


}
