package uo.ri.cws.application.service.invoice.create.command;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ChargeRepository;
import uo.ri.cws.application.repository.CreditCardRepository;
import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.repository.VoucherRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Charge;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.domain.Invoice.InvoiceStatus;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.cws.domain.Voucher;
import uo.ri.util.assertion.ArgumentChecks;

public class SettleInvoice implements Command<Void> {

	
	private String id;
	private Map<String, Double> charges;
	private InvoiceRepository invr=Factory.repository.forInvoice();
	private PaymentMeanRepository payr=Factory.repository.forPaymentMean();
	private ChargeRepository charR=Factory.repository.forCharge();
	private CreditCardRepository crer=Factory.repository.forCreditCard();
	private VoucherRepository vour=Factory.repository.forVoucher();
	
	public SettleInvoice(String invoiceId, Map<String, Double> charges) {
		ArgumentChecks.isNotNull(invoiceId);
		ArgumentChecks.isNotNull(charges);
		ArgumentChecks.isNotEmpty(invoiceId);
		this.id=invoiceId;
		this.charges=charges;
	}

	@Override
	public Void execute() throws BusinessException {
		Double amount=0.0;
		Optional<Invoice> inv=invr.findById(id);
		Optional<PaymentMean> pay=null;
		BusinessChecks.isTrue(inv.isPresent(),"No existe la invoice");
		BusinessChecks.isTrue(inv.get().getStatus()==InvoiceStatus.PAID,
				"No existe la invoice");
		for(String idPayment:charges.keySet()) {//int valor=mapa.get(idPayment)
			BusinessChecks.isTrue(idPayment!=null,"No hay registrado metodo ed pago");
			pay=payr.findById(idPayment);
			BusinessChecks.isTrue(pay.isPresent(),"No hay ergistrado metodod e pago");
			Voucher voucher=null;
			CreditCard cc=null;
			if(crer.findById(pay.get().getId()).isPresent()) {//Descubrir comop hacerlo
				cc=crer.findById(pay.get().getId()).get();
				BusinessChecks.isTrue(cc.getValidThru().isAfter(LocalDate.now()),
						"La tarjeta esta caducada");
			}else if(vour.findById(pay.get().getId()).isPresent()) {//Descubrir comop hacerlo
				voucher=vour.findById(pay.get().getId()).get();
				if(voucher.getAvailable()>=charges.get(idPayment)) {
					voucher.payInvoice(charges.get(idPayment));
				}else {
					throw new BusinessException("El bono no tiene suficiente saldo disponible");
				}
			}
			amount+=charges.get(idPayment);
			Charge c=new Charge(inv.get(), pay.get(), charges.get(idPayment));
			charR.add(c);
		}
		if(Math.abs( inv.get().getAmount() - amount) > 0.01)
			throw new BusinessException("Existe una diferencia en el"
					+ " amount de invoice y de los cargos");
		inv.get().markAsPaid();
		return null;
	}

}
