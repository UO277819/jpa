package uo.ri.cws.application.service.client.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.crud.command.AddClient;
import uo.ri.cws.application.service.client.crud.command.DeleteClient;
import uo.ri.cws.application.service.client.crud.command.FindAllClients;
import uo.ri.cws.application.service.client.crud.command.FindClientById;
import uo.ri.cws.application.service.client.crud.command.FindClientsRecommendedBy;
import uo.ri.cws.application.service.client.crud.command.UpdateClient;
import uo.ri.cws.application.util.command.CommandExecutor;

public class ClientCrudServiceImpl implements ClientCrudService {

	private CommandExecutor executor = Factory.executor.forExecutor();
	
	@Override
	public ClientDto addClient(ClientDto client) throws BusinessException {
		return executor.execute(new AddClient(client));
	}

	@Override
	public void deleteClient(String cliente_id) throws BusinessException {
		executor.execute(new DeleteClient(cliente_id));
	}

	@Override
	public void updateClient(ClientDto client) throws BusinessException {
		executor.execute(new UpdateClient(client));
	}

	@Override
	public List<ClientDto> findAllClients() throws BusinessException {
		return executor.execute(new FindAllClients());
	}

	@Override
	public Optional<ClientDto> findClientById(String cliente_id) throws BusinessException {
		return executor.execute(new FindClientById(cliente_id));
	}

	@Override
	public List<ClientDto> findClientsRecommendedBy(String sponsor_id) throws BusinessException {
		return executor.execute(new FindClientsRecommendedBy(sponsor_id));
	}
}
