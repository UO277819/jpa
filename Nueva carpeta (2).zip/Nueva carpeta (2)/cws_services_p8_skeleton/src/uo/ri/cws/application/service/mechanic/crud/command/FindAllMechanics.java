package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;

public class FindAllMechanics implements Command<List<MechanicDto>>{

	public List<MechanicDto> execute() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("carWorkshop");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		//TypedQuery q=em.createNamedQuery("Mechanic.delete",Mechanic.class).setParameter(1, mechanicId);
		//List<Mechanic> l=q.getResultList();
		//BusinessChecks.isFalse(l.isEmpty(),"no delete");
		TypedQuery q=em.createNamedQuery("Mechanic.findAll",Mechanic.class);
		List<MechanicDto> lista=q.getResultList();
		tx.commit();
		return lista;
	}

}
