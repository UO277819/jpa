package uo.ri.cws.application.service.invoice.create.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoicingWorkOrderDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.Vehicle;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class FindNotInvoiceWorkOrderByClientDni implements Command<List<InvoicingWorkOrderDto>> {

	private String dni;
	private ClientRepository clir=Factory.repository.forClient();

	public FindNotInvoiceWorkOrderByClientDni(String dni) {
		ArgumentChecks.isNotNull(dni);
		ArgumentChecks.isNotEmpty(dni);
		this.dni=dni;
	}

	@Override
	public List<InvoicingWorkOrderDto> execute() throws BusinessException {
		Optional<Client> cliente=clir.findByDni(dni);
		BusinessChecks.isTrue(cliente.isPresent(),"No hay cliente");
		Client c=cliente.get();
		Set<Vehicle> veh=c.getVehicles();
		List<InvoicingWorkOrderDto> w=new ArrayList<>();
		for(Vehicle v:veh) {
			for(WorkOrder work:v.getWorkOrders()) {
				w.add(DtoAssembler.toWorkOrderDtoForWorkRecord(work));
			}
		}
		return w;
	}

}
