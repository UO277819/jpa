package uo.ri.cws.application.service.client.crud.command;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import alb.util.assertion.ArgumentChecks;
import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.CashRepository;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.CreditCardRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.repository.RecommendationRepository;
import uo.ri.cws.application.repository.VoucherRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Cash;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.cws.domain.Recommendation;
import uo.ri.cws.domain.Voucher;

public class DeleteClient implements Command<Void> {

	public String id;
	private ClientRepository cRepo = Factory.repository.forClient();
	private PaymentMeanRepository pRepo = Factory.repository.forPaymentMean();
	private RecommendationRepository rRepo = Factory.repository.forRecomendacion();
	private CashRepository cashr = Factory.repository.forCash();
	private CreditCardRepository credr = Factory.repository.forCreditCard();
	private VoucherRepository vour = Factory.repository.forVoucher();
	
	public DeleteClient(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotEmpty(id);	
		this.id = id;
	}
	
	@Override
	public Void execute() throws BusinessException {
		Optional<Client> cliente = cRepo.findById(id);
		BusinessChecks.isTrue(!cliente.isEmpty(), "No Existe");
		BusinessChecks.isTrue(!cliente.get().getVehicles().isEmpty(), "No se puede borrar");
		Client c=cliente.get();
		List<PaymentMean> pay = pRepo.findByClientId(id);
		for (PaymentMean paymentMean : pay) {
			if(cashr.findById(paymentMean.getId()).isPresent())
				cashr.remove((Cash) paymentMean);
			else if(credr.findById(paymentMean.getId()).isPresent())
				credr.remove((CreditCard) paymentMean);
			else
				vour.remove((Voucher) paymentMean);
			pRepo.remove(paymentMean);
		}
		if(c.getRecommended()!=null)
			rRepo.remove(c.getRecommended());
		Set<Recommendation> sponsors = c.getSponsored();
		for (Recommendation recom : sponsors) {
			rRepo.remove(recom);
		}
		cRepo.remove(c);
		return null;
	}
	
}
